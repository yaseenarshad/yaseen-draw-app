export declare function inputId(prefix: string): string;
//# sourceMappingURL=unique-id.d.ts.map