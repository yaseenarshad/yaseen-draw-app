import type { MilkdownPlugin } from '@milkdown/ctx';
export * from './config';
export { diffDecorationPlugin } from './diff-decoration-plugin';
export declare const diffComponent: MilkdownPlugin[];
//# sourceMappingURL=index.d.ts.map