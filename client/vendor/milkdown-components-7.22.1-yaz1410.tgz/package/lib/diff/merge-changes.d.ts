import type { Change } from '@milkdown/prose/changeset';
import type { Node } from '@milkdown/prose/model';
export interface MergedChange {
    fromA: number;
    toA: number;
    fromB: number;
    toB: number;
    isCustomBlock: boolean;
}
export interface ChangeSegment {
    fromA: number;
    toA: number;
    fromB: number;
    toB: number;
    isBlock: boolean;
}
export declare function splitCrossBoundaryChange(doc: Node, newDoc: Node, change: MergedChange): ChangeSegment[] | null;
export declare function mergeBlockChanges(pending: readonly Change[], doc: Node, newDoc: Node, customBlockTypes: Set<string>): MergedChange[];
export declare function anchorTrailingInsertsBeforeEmptyParagraph(changes: MergedChange[], doc: Node): void;
//# sourceMappingURL=merge-changes.d.ts.map