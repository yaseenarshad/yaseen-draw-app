export declare const DIFF_CLASS_PREFIX = "milkdown-diff";
export interface DiffComponentConfig {
    acceptLabel: string;
    rejectLabel: string;
    customBlockTypes: string[];
}
export declare const diffComponentConfig: import("@milkdown/utils").$Ctx<DiffComponentConfig, "diffComponentConfig">;
//# sourceMappingURL=config.d.ts.map