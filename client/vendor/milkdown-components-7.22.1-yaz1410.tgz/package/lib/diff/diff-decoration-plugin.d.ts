export declare const diffDecorationPlugin: import("@milkdown/utils").$Prose;
//# sourceMappingURL=diff-decoration-plugin.d.ts.map