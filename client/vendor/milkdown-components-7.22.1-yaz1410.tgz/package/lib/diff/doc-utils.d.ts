import type { Node } from '@milkdown/prose/model';
import { Decoration } from '@milkdown/prose/view';
export declare function isBlockSpanning(doc: Node, from: number, to: number): boolean;
export declare function hasBlockContent(doc: Node, from: number, to: number): boolean;
export declare function coversOnlyTrailingEmptyParagraphs(doc: Node, from: number, to: number): boolean;
export declare function trailingEmptyParagraphStart(doc: Node): number;
export declare function snapToBlockBoundary(doc: Node, pos: number): number;
export declare function forEachTopLevelNodeInRange(doc: Node, from: number, to: number, callback: (node: Node, start: number, end: number) => void): void;
export declare function addBlockDeletionDecorations(doc: Node, from: number, to: number, decorations: Decoration[]): void;
export declare function getTopLevelBlockRange(doc: Node, pos: number, endBoundary?: boolean): {
    from: number;
    to: number;
} | null;
export declare function getCustomBlockAncestor(doc: Node, pos: number, customBlockTypes: Set<string>): string | null;
export declare function getCustomBlockAt(doc: Node, pos: number, customBlockTypes: Set<string>, endBoundary?: boolean): string | null;
export declare function collectTopLevelNodes(doc: Node, from: number, to: number): Node[];
//# sourceMappingURL=doc-utils.d.ts.map