import type { Node } from '@milkdown/prose/model';
import type { EditorView, NodeView } from '@milkdown/prose/view';
import { EditorView as CodeMirror } from '@codemirror/view';
import { type App } from 'vue';
import type { CodeBlockConfig } from '../config';
import type { LanguageLoader } from './loader';
export declare class CodeMirrorBlock implements NodeView {
    node: Node;
    view: EditorView;
    getPos: () => number | undefined;
    loader: LanguageLoader;
    config: CodeBlockConfig;
    /** Delay before tearing down an off-screen CodeMirror instance. */
    static TEARDOWN_DELAY: number;
    dom: HTMLElement;
    cm: CodeMirror;
    app: App;
    selected: import("vue").Ref<boolean, boolean>;
    language: import("vue").Ref<string, string>;
    text: import("vue").Ref<string, string>;
    private initialized;
    private updating;
    private languageName;
    private disposeSelectedWatcher;
    private teardownTimer;
    private readonly languageConf;
    private readonly readOnlyConf;
    constructor(node: Node, view: EditorView, getPos: () => number | undefined, loader: LanguageLoader, config: CodeBlockConfig);
    private renderPlaceholder;
    private initializeCodeMirror;
    private teardownCodeMirror;
    private scheduleTeardown;
    private cancelTeardown;
    private forwardUpdate;
    private createApp;
    private updateLanguage;
    private codeMirrorKeymap;
    private maybeEscape;
    setSelection(anchor: number, head: number): void;
    update(node: Node): boolean;
    selectNode(): void;
    deselectNode(): void;
    stopEvent(): boolean;
    destroy(): void;
    setLanguage: (language: string) => void;
    getAllLanguages: () => import("./loader").LanguageInfo[];
}
//# sourceMappingURL=node-view.d.ts.map