import type { NodeViewConstructor } from '@milkdown/prose/view';
import { CodeMirrorBlock } from './node-view';
export { CodeMirrorBlock };
export declare const codeBlockView: import("@milkdown/utils").$View<import("@milkdown/utils").$Node, NodeViewConstructor>;
//# sourceMappingURL=index.d.ts.map