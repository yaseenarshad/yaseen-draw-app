function getEffectiveCSSZoom(element: Element): number {
  const zoom = (element as Element & { currentCSSZoom?: number }).currentCSSZoom
  return Number.isFinite(zoom) && zoom! > 0 ? zoom! : 1
}

export function clearPreview(previewRoot: HTMLElement) {
  while (previewRoot.firstChild) previewRoot.removeChild(previewRoot.firstChild)
}

export function renderPreview(
  axis: 'x' | 'y',
  preview: HTMLElement,
  previewRoot: HTMLElement,
  tableContent: HTMLElement,
  index: number
) {
  const zoom = getEffectiveCSSZoom(tableContent)
  const { width: tableWidth, height: tableHeight } = tableContent
    .querySelector('tbody')!
    .getBoundingClientRect()
  if (axis === 'y') {
    const rows = tableContent.querySelectorAll('tr')
    const row = rows[index]
    if (!row) return

    previewRoot.appendChild(row.cloneNode(true))
    const height = row.getBoundingClientRect().height

    Object.assign(preview.style, {
      width: `${tableWidth / zoom}px`,
      height: `${height / zoom}px`,
    })

    preview.dataset.show = 'true'

    return
  }

  if (axis === 'x') {
    const rows = tableContent.querySelectorAll('tr')
    let width: number | undefined

    Array.from(rows).forEach((row) => {
      const col = row.children[index]
      if (!col) return

      if (width === undefined) width = col.getBoundingClientRect().width

      const tr = col.parentElement!.cloneNode(false)
      const clone = col.cloneNode(true)
      tr.appendChild(clone)
      previewRoot.appendChild(tr)
    })

    Object.assign(preview.style, {
      width: `${width! / zoom}px`,
      height: `${tableHeight / zoom}px`,
    })

    preview.dataset.show = 'true'

    return
  }
}
